class UIUtils {
  constructor(chatUI) {
    this.chatUI = chatUI;
  }

  // Add any additional UI utility methods here if needed
}

export default UIUtils;