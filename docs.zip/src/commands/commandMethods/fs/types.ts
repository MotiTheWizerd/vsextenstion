export type FileReadOptions = {
    autoAnalyze?: boolean;
    encoding?: BufferEncoding;
  };
  
  export const DEFAULT_READ_OPTIONS: FileReadOptions = {
    autoAnalyze: true,
    encoding: 'utf-8',
  };
  
  export interface FileListingOptions {
    showHidden?: boolean;
    recursive?: boolean;   // reserved for future, not used yet (kept for compatibility)
    maxDepth?: number;     // reserved for future, not used yet (kept for compatibility)
  }
  
  export interface FileEntry {
    name: string;
    path: string;
    type: 'file' | 'directory' | 'symbolic-link' | 'other';
    size?: number;
    modified?: Date;
  }
  